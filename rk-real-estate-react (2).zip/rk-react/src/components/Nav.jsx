import { Link } from 'react-router-dom'

function Monogram() {
  return (
    <svg className="monogram" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 22V4h7.5a5 5 0 0 1 0 10H8l9 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  )
}

export default function Nav() {
  return (
    <header className="nav">
      <div className="wrap">
        <ul className="nav-links">
          <li><Link to="/#services">Services</Link></li>
          <li><Link to="/#process">Process</Link></li>
          <li><Link to="/blog">Blog</Link></li>
        </ul>
        <Link to="/" aria-label="RK Real Estate Consultant — home"><Monogram /></Link>
        <Link className="btn btn-ghost" to="/#contact">Contact Us</Link>
      </div>
    </header>
  )
}
