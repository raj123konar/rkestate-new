import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer-row">
          <div className="footer-brand">RK Real Estate Consultant</div>
          <ul className="footer-links">
            <li><Link to="/#services">Services</Link></li>
            <li><Link to="/#process">Process</Link></li>
            <li><Link to="/blog">Blog</Link></li>
            <li><Link to="/#contact">Contact</Link></li>
          </ul>
        </div>
        <div className="footer-bottom">
          <span>© 2026 RK Real Estate Consultant. All rights reserved.</span>
          <span>Nerul, Navi Mumbai · 9322043670 / 8080005351</span>
        </div>
      </div>
    </footer>
  )
}
