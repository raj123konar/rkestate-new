import { useRef } from 'react'
import { Link } from 'react-router-dom'
import { blogPosts } from '../blogPosts.js'
import { useScrollReveal } from '../hooks/useScrollReveal.js'

const WHATSAPP_NUMBER = '919322043670'

function PlatPattern() {
  return (
    <svg className="hero-plat" viewBox="0 0 1200 640" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
      <polygon className="draw" points="140,120 520,90 560,420 220,480 90,300" fill="none" stroke="#f9f8f0" strokeWidth="1" />
      <polygon className="draw" points="700,180 1080,140 1120,440 780,500 660,340" fill="none" stroke="#f9f8f0" strokeWidth="1" />
      <line className="draw" x1="140" y1="120" x2="560" y2="420" stroke="#f9f8f0" strokeWidth="0.6" />
      <line className="draw" x1="520" y1="90" x2="220" y2="480" stroke="#f9f8f0" strokeWidth="0.6" />
      <g className="skyline-accent" stroke="#e97451" strokeWidth="1.2" fill="none" opacity="0.55">
        <rect className="draw" x="80" y="500" width="60" height="140" />
        <rect className="draw" x="150" y="460" width="70" height="180" />
        <rect className="draw" x="230" y="520" width="50" height="120" />
        <polygon className="draw" points="255,520 280,500 305,520" />
        <rect className="draw" x="950" y="480" width="65" height="160" />
        <rect className="draw" x="1030" y="440" width="80" height="200" />
        <rect className="draw" x="1010" y="420" width="20" height="20" />
      </g>
    </svg>
  )
}

function FacadeIllustration() {
  return (
    <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="30" y="60" width="140" height="120" stroke="#3c261c" strokeWidth="1.4" fill="none" />
      <rect x="30" y="60" width="140" height="14" fill="#e97451" opacity="0.85" />
      <line x1="30" y1="100" x2="170" y2="100" stroke="#3c261c" strokeWidth="0.8" />
      <line x1="30" y1="140" x2="170" y2="140" stroke="#3c261c" strokeWidth="0.8" />
      <rect x="42" y="84" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="68" y="84" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="116" y="84" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="142" y="84" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="42" y="124" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="68" y="124" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="116" y="124" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="142" y="124" width="16" height="14" stroke="#3c261c" strokeWidth="1" />
      <rect x="90" y="150" width="20" height="30" stroke="#3c261c" strokeWidth="1.4" />
      <line x1="10" y1="180" x2="190" y2="180" stroke="#3c261c" strokeWidth="1.6" />
    </svg>
  )
}

function DocumentIllustration() {
  return (
    <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="55" y="30" width="90" height="120" rx="2" stroke="#3c261c" strokeWidth="1.4" fill="none" />
      <line x1="70" y1="55" x2="130" y2="55" stroke="#e97451" strokeWidth="1.6" />
      <line x1="70" y1="72" x2="130" y2="72" stroke="#3c261c" strokeWidth="0.8" />
      <line x1="70" y1="84" x2="130" y2="84" stroke="#3c261c" strokeWidth="0.8" />
      <line x1="70" y1="96" x2="110" y2="96" stroke="#3c261c" strokeWidth="0.8" />
      <circle cx="130" cy="130" r="16" stroke="#3c261c" strokeWidth="1.2" fill="none" />
      <path d="M124 130l4 4 8-9" stroke="#e97451" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="30" y1="170" x2="170" y2="170" stroke="#3c261c" strokeWidth="1" strokeDasharray="3 3" />
    </svg>
  )
}

export default function Home() {
  const formRef = useRef(null)
  const featured = blogPosts.slice(0, 3)
  useScrollReveal()

  function sendToWhatsApp(e) {
    e.preventDefault()
    const data = new FormData(formRef.current)
    const lines = [
      'New enquiry from the RK Real Estate Consultant website:',
      `Name: ${data.get('name') || '-'}`,
      `Phone: ${data.get('phone') || '-'}`,
      `Email: ${data.get('email') || '-'}`,
      `Looking to: ${data.get('interest')}`,
      `Message: ${data.get('message') || '-'}`
    ]
    const text = encodeURIComponent(lines.join('\n'))
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, '_blank')
  }

  return (
    <>
      <section className="hero">
        <PlatPattern />
        <div className="wrap hero-inner">
          <div className="hero-eyebrow">Independent Property Counsel — Nerul, Navi Mumbai</div>
          <h1 className="hero-display">Every property tells its own story.</h1>
          <p className="hero-sub">
            RK Real Estate Consultant represents buyers, sellers, investors, and rental property
            seekers with the same rigor a title company brings to a closing — researched,
            documented, and free of sales pressure.
          </p>
          <div className="hero-ctas">
            <a className="btn btn-primary" href="#contact">Book a Consultation</a>
            <a className="btn btn-ghost" href="tel:9322043670">Call Us</a>
          </div>
        </div>
      </section>

      <section className="stats">
        <div className="stats-row">
          <div className="stat reveal"><div className="num">17</div><div className="label">Years in Practice</div></div>
          <div className="stat reveal"><div className="num">₹10 Cr</div><div className="label">Closed Transaction Volume</div></div>
          <div className="stat reveal"><div className="num">94%</div><div className="label">Asking-to-Sale Ratio</div></div>
          <div className="stat reveal"><div className="num">31</div><div className="label">Avg. Days on Market</div></div>
        </div>
      </section>

      <section className="section" id="services">
        <div className="wrap content-grid">
          <div className="art reveal">
            <div className="art-frame facade-frame"><FacadeIllustration /></div>
          </div>
          <div className="copy reveal">
            <div className="section-eyebrow">What We Do</div>
            <h2 className="section-heading">Four Ways to Work With Us</h2>
            <p className="section-body">
              Each engagement starts with the same document review most agents skip —
              before any showing, offer, or listing price is discussed.
            </p>
            <ul className="feature-list reveal-stagger">
              <li className="reveal-item"><span className="dot" /><div><strong>Buyer representation</strong>We review title history, zoning, and permit records before you make an offer.</div></li>
              <li className="reveal-item"><span className="dot" /><div><strong>Seller advisory</strong>Pricing strategy and negotiation built on a documented comparable file.</div></li>
              <li className="reveal-item"><span className="dot" /><div><strong>Investment consulting</strong>Cash-flow modeling and portfolio review for buy-and-hold investors.</div></li>
              <li className="reveal-item"><span className="dot" /><div><strong>Rental property</strong>We help you find the right room or rental property to stay in.</div></li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section alt" id="process">
        <div className="wrap content-grid reverse">
          <div className="copy reveal">
            <div className="section-eyebrow">How an Engagement Runs</div>
            <h2 className="section-heading">Four Stages, Start to Close</h2>
            <p className="section-body">
              The order doesn't change client to client — only how long each stage takes.
            </p>
            <ul className="feature-list reveal-stagger">
              <li className="reveal-item"><span className="idx">01</span><div><strong>Consultation</strong>We map your goals, budget, and timeline.</div></li>
              <li className="reveal-item"><span className="idx">02</span><div><strong>Property &amp; title review</strong>Title chain, zoning, permits, and a written comparable file.</div></li>
              <li className="reveal-item"><span className="idx">03</span><div><strong>Offer &amp; contract</strong>We draft, counter, and negotiate on documented facts.</div></li>
              <li className="reveal-item"><span className="idx">04</span><div><strong>Closing &amp; transition</strong>Final walkthrough, closing coordination, and a full handoff packet.</div></li>
            </ul>
          </div>
          <div className="art reveal">
            <div className="art-frame"><DocumentIllustration /></div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <div className="section-eyebrow reveal" style={{ textAlign: 'center' }}>Client Record</div>
          <blockquote className="pull-quote reveal">
            “We were looking for a 2BHK in Nerul for almost two months with no luck. Kishor sir
            understood exactly what we needed and showed us only genuine options — no time waste.”
            <cite>Sandeep Kulkarni — Nerul, Navi Mumbai</cite>
          </blockquote>
          <div className="testi-row reveal-stagger">
            <div className="testi-card reveal-item">
              <p>Very honest advice while selling my flat in Vashi. He explained the market rate clearly and got us a better deal than expected within three weeks.</p>
              <div className="who">Anita Sawant — Vashi, Navi Mumbai</div>
            </div>
            <div className="testi-card reveal-item">
              <p>The cash-flow model they built for our second rental turned out more accurate than the one our accountant gave us.</p>
              <div className="who">S. Patel — Investor</div>
            </div>
          </div>
        </div>
      </section>

      <section className="section alt">
        <div className="wrap content-grid">
          <div className="art reveal" style={{ display: 'flex', alignItems: 'flex-start' }}>
            <div>
              <div className="badge"><span>KD</span></div>
            </div>
          </div>
          <div className="copy reveal">
            <div className="section-eyebrow">Principal Broker</div>
            <h2 className="section-heading" style={{ textTransform: 'none', fontFamily: 'var(--font-paradigm-pro)', fontWeight: 300, letterSpacing: '0.03em' }}>
              Kishor Deshmukh
            </h2>
            <p className="section-body">
              Kishor founded RK Real Estate Consultant after eleven years working the title side
              of real estate, closing the gap he kept seeing between what buyers were told and
              what the records actually showed. He now leads a four-person team that treats due
              diligence as the whole job, not a step before it.
            </p>
            <div className="credentials">
              <div><strong>MahaRERA Reg.</strong><span>Registered consultant, est. 2009</span></div>
              <div><strong>Prior role</strong><span>Title examiner, 8 yrs</span></div>
              <div><strong>Focus</strong><span>Residential &amp; small multi-family</span></div>
            </div>
          </div>
        </div>
      </section>

      <section className="section" id="blog-preview">
        <div className="wrap">
          <div className="section-eyebrow reveal">From the Blog</div>
          <h2 className="section-heading reveal">Notes on Buying, Selling &amp; Renting Locally</h2>
          <p className="section-body reveal">
            Straightforward, no-jargon guides to the paperwork and decisions that actually
            matter — written for buyers, sellers, and renters in Navi Mumbai.
          </p>
          <div className="blog-grid preview reveal-stagger">
            {featured.map(post => (
              <Link key={post.slug} to={`/blog/${post.slug}`} className="blog-card reveal-item">
                <div className="meta">{new Date(post.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
                <span className="title">{post.title}</span>
                <p>{post.excerpt}</p>
              </Link>
            ))}
          </div>
          <div style={{ marginTop: 34 }}>
            <Link className="btn btn-primary on-light" to="/blog" style={{ borderColor: 'var(--color-espresso-bark)', color: 'var(--color-espresso-bark)' }}>
              Read All Articles
            </Link>
          </div>
        </div>
      </section>

      <section className="section contact" id="contact">
        <div className="wrap">
          <div className="section-eyebrow">Get in Touch</div>
          <h2 className="section-heading">Request a Consultation</h2>
          <p className="section-body">Tell us what you're working on. We reply within one business day.</p>

          <div className="contact-grid">
            <ul className="feature-list">
              <li><span className="dot" /><div><span className="label">Office</span>Shop No. 02, Dwarkanath Apartment, Sector-20, Plot No. D-115, Near Agri Koli Bhawan, Nerul, Navi Mumbai-400706</div></li>
              <li><span className="dot" /><div><span className="label">Phone</span><a href="tel:9322043670">9322043670</a> / <a href="tel:8080005351">8080005351</a></div></li>
              <li><span className="dot" /><div><span className="label">Email</span><a href="mailto:rkrealestate40@gmail.com">rkrealestate40@gmail.com</a></div></li>
              <li><span className="dot" /><div><span className="label">Hours</span>Everyday, 9:00–19:00</div></li>
            </ul>

            <form className="form-panel" ref={formRef} onSubmit={sendToWhatsApp}>
              <div className="field-row">
                <div>
                  <label htmlFor="name">Full name</label>
                  <input id="name" name="name" type="text" placeholder="Enter your name" required />
                </div>
                <div>
                  <label htmlFor="phone">Phone</label>
                  <input id="phone" name="phone" type="tel" placeholder="98765 43210" />
                </div>
              </div>
              <label htmlFor="email">Email</label>
              <input id="email" name="email" type="email" placeholder="you@example.com" required />
              <label htmlFor="interest">I'm looking to</label>
              <select id="interest" name="interest" defaultValue="Buy a property">
                <option>Buy a property</option>
                <option>Sell a property</option>
                <option>Rent my property</option>
                <option>Want rental property</option>
                <option>Get investment consulting</option>
                <option>Something else</option>
              </select>
              <label htmlFor="message">What should we know?</label>
              <textarea id="message" name="message" placeholder="Timeline, budget, neighborhoods you're considering…" />
              <button className="btn btn-primary on-light" type="submit">Send via WhatsApp</button>
              <div className="form-note">Opens WhatsApp with your details filled in — just hit send.</div>
            </form>
          </div>
        </div>
      </section>
    </>
  )
}
