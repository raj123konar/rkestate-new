import { useParams, Link, Navigate } from 'react-router-dom'
import Seo from '../components/Seo.jsx'
import { blogPosts } from '../blogPosts.js'
import { useScrollReveal } from '../hooks/useScrollReveal.js'

export default function BlogPost() {
  const { slug } = useParams()
  const post = blogPosts.find(p => p.slug === slug)
  useScrollReveal([slug])

  if (!post) return <Navigate to="/blog" replace />

  const paragraphs = post.content.trim().split('\n\n')

  return (
    <>
      <Seo
        title={`${post.title} | RK Real Estate Consultant`}
        description={post.metaDescription}
      />
      <article className="section" style={{ paddingTop: 68 }}>
        <div className="wrap" style={{ maxWidth: 760 }}>
          <Link to="/blog" style={{ fontSize: 13, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--color-terracotta-ember)', textDecoration: 'none' }}>
            ← All Articles
          </Link>
          <div className="section-eyebrow reveal" style={{ marginTop: 30 }}>
            {new Date(post.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
          </div>
          <h1 className="section-heading reveal" style={{ textTransform: 'none', fontSize: 34, letterSpacing: '0.01em' }}>
            {post.title}
          </h1>

          <div className="reveal" style={{ marginTop: 30 }}>
            {paragraphs.map((para, i) => {
              if (para.startsWith('## ')) {
                return (
                  <h2 key={i} style={{ fontFamily: 'var(--font-monasans)', fontWeight: 600, fontSize: 20, marginTop: 34, marginBottom: 12, color: 'var(--color-espresso-bark)' }}>
                    {para.replace('## ', '')}
                  </h2>
                )
              }
              return <p key={i} className="section-body" style={{ maxWidth: 'none' }}>{para}</p>
            })}
          </div>

          <div className="reveal" style={{ marginTop: 45, padding: 30, background: 'var(--color-blush-cream)', borderRadius: 'var(--radius-sm)' }}>
            <strong style={{ display: 'block', marginBottom: 10 }}>Have a question about your own situation?</strong>
            <p style={{ margin: '0 0 18px' }}>We're happy to walk through it — no obligation.</p>
            <Link className="btn btn-primary on-light" to="/#contact" style={{ borderColor: 'var(--color-terracotta-ember)' }}>
              Talk to Us
            </Link>
          </div>
        </div>
      </article>
    </>
  )
}
