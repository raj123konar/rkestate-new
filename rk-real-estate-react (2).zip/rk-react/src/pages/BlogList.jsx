import { Link } from 'react-router-dom'
import Seo from '../components/Seo.jsx'
import { blogPosts } from '../blogPosts.js'
import { useScrollReveal } from '../hooks/useScrollReveal.js'

export default function BlogList() {
  useScrollReveal()

  return (
    <>
      <Seo
        title="Real Estate Blog | RK Real Estate Consultant, Nerul, Navi Mumbai"
        description="Guides on buying, selling, and renting property in Navi Mumbai — title verification, stamp duty, MahaRERA, and locality comparisons."
      />
      <section className="section" style={{ paddingTop: 68 }}>
        <div className="wrap">
          <div className="section-eyebrow reveal">Resources</div>
          <h1 className="section-heading reveal">The RK Real Estate Blog</h1>
          <p className="section-body reveal">
            Practical, no-jargon guides for buyers, sellers, and renters in Nerul, Vashi, and
            wider Navi Mumbai — written from what we actually see in transactions.
          </p>

          <div className="blog-grid reveal-stagger" style={{ marginTop: 45 }}>
            {blogPosts.map(post => (
              <Link key={post.slug} to={`/blog/${post.slug}`} className="blog-card reveal-item">
                <div className="meta">
                  {new Date(post.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                </div>
                <span className="title" style={{ fontSize: 20 }}>{post.title}</span>
                <p>{post.excerpt}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
